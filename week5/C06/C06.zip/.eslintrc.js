module.exports = {
    "extends": "airbnb-base",
    "rules":{
        "linebreak-style": ["error", "windows"],
        "no-plusplus": ["error", { "allowForLoopAfterthoughts": true }]
    }
    
};